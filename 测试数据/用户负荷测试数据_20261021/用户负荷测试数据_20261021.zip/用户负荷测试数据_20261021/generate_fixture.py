#!/usr/bin/env python3
"""Generate deterministic TDengine load fixtures. Does not connect to any database."""
from pathlib import Path
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from collections import Counter
import argparse, csv, hashlib, json, re, shutil, zipfile

D = Decimal
SPECS = [
('3750016959530','S01','正常选样；另测00:15跨日初始化','10',5,0,0,None,'10',None,None),
('3750016959531','S02','缺点先跳过，继续选更早真实值','10',5,0,0,None,'10',None,None),
('3750016959532','S03','仅1个真实样本，补4个同类型拟合样本','10',5,4,0,None,'10',None,None),
('3750016959533','S04','整日缺失仍可作为拟合目标日','10',5,1,0,None,'10',None,None),
('3750016959534','S05','只有最近1天可用，有几天算几天','10',1,0,0,None,'10',None,None),
('3750016959535','S06','历史同一点均缺失，仅该点无基线',None,0,0,0,None,None,None,None),
('3750016959536','S07','18恰好等于均值12的1.5倍，不剔除','12',5,0,0,None,'12',None,None),
('3750016959537','S08','剔除单个高值，K上调到1.2','10',5,0,1,'1.2','12','12','10'),
('3750016959538','S09','10:15和10:30连续修正，滚动使用最终值','10',5,0,1,'1.2','12','12','10'),
('3750016959539','S10','剔除后K下调到0.8','10',5,0,1,'0.8','8','8','10'),
('3750016959540','S11','实际负荷为0，K=0，结果为0','10',5,0,1,'0','0','0','10'),
('3750016959541','S12','历史基线窗口均值0，无法修正','10',5,0,1,None,'10','12','0'),
('3750016959542','S13','实际07:30缺点，同距离优先前值','10',5,0,1,'1.175','11.75','11.75','10'),
('3750016959543','S14','实际06:15无可用前值，采用06:30后值','10',5,0,1,'1.225','12.25','12.25','10'),
('3750016959544','S15','实际窗口及可拟合范围无值，无法修正','10',5,0,1,None,'10',None,'10'),
('3750016959545','S16','历史基线07:30空，用最近已发布前值','10',5,0,1,'1.2','12','12','10'),
('3750016959546','S17','[100,100,10,10,10]一次剔除两个高值','10',5,0,2,'1.2','12','12','10'),
('3750016959547','S18','[100,40,10,10,10]只剔除100，不迭代','17.5',5,0,1,'1.2','21','12','10'),
('3750016959548','S19','只有[40,10]两个样本，仍按实际数量剔除','10',2,0,1,'1.2','12','12','10'),
('3750016959549','S20','零负荷是有效样本；来源类型为空','0',5,0,0,None,'0',None,None),
]


def sqlstr(value):
    if value is None:
        return 'NULL'
    return "'" + str(value).replace("'", "''") + "'"


def fmt(value):
    return 'NULL' if value is None else format(value, '.4f').rstrip('0').rstrip('.') if value else '0'


def workdays_before(target, n=5):
    out=[]; current=target-timedelta(days=1)
    while len(out)<n:
        if current.weekday()<5: out.append(current)
        current-=timedelta(days=1)
    return out


def special_load(account, business_date, slot, target, previous):
    code = int(account[-2:]) - 30 + 1
    base = D('10') if business_date.weekday()<5 else D('20')
    historical = business_date < target
    if code == 20:
        return D('0')
    if historical:
        if code == 1 and business_date == previous[0] and slot == 1:
            return D('30')
        if code in (3,4) and business_date == previous[0]:
            return None
        if code == 16 and slot == 30:
            return None
        if code == 12 and slot != 41:
            return D('0')
        if slot == 41:
            if code == 2 and business_date == previous[0]: return None
            if code == 3: return D('10') if business_date == previous[-1] else None
            if code == 4: return D('10') if business_date in previous[1:] else None
            if code == 5: return D('10') if business_date == previous[0] else None
            if code == 6: return None
            if code == 7 and business_date in previous:
                return D('18') if business_date == previous[0] else D('10.5')
            if code == 17 and business_date in previous[:2]: return D('100')
            if code == 18:
                if business_date == previous[0]: return D('100')
                if business_date == previous[1]: return D('40')
            if code == 19:
                return D('40') if business_date == previous[0] else D('10') if business_date == previous[1] else None
            if code in (8,9,10,11,12,13,14,15,16) and business_date == previous[0]:
                return D('30')
            if code == 12: return D('10')
        if code == 9 and slot == 42 and business_date == previous[0]:
            return D('30')
        return base
    if code in (8,9,12,13,14,15,16,17,18,19): base=D('12')
    if code == 10: base=D('8')
    if code == 11: base=D('0')
    if code == 13:
        if slot == 29: return D('8')
        if slot == 30: return None
        if slot == 31: return D('16')
    if code == 14:
        if slot <= 25: return None
        if slot == 26: return D('14')
    if code == 15 and slot <= 41: return None
    return base


def single_line_sql(text):
    """Format our generated SQL with one complete statement per physical line for taos -f."""
    result = []
    pending = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('--'):
            assert not pending, 'Unexpected comment inside generated SQL'
            result.append(line)
            continue
        pending.append(line)
        if line.endswith(';'):
            result.append(' '.join(pending))
            pending = []
    assert not pending, 'Incomplete generated SQL statement'
    return '\n'.join(result) + '\n'


def schema_sql(accounts, database, repo, start, days):
    source=f"""-- Use the existing database. Existing supertables are preserved.
USE {database};
CREATE STABLE IF NOT EXISTS st_user_load_96 (
    ts TIMESTAMP,
    load_mw DOUBLE,
    src_type NCHAR(20)
) TAGS (cons_no NCHAR(40), data_date NCHAR(10));
"""
    baseline=(repo/'用户基线-tdengine.sql').read_text()
    source+='\n'+baseline[baseline.index('CREATE STABLE'):]+ '\n'
    for offset in range(days):
        business_date=start+timedelta(days=offset)
        for account in accounts:
            table='fixture_load_'+hashlib.sha256(account.encode()).hexdigest()[:24]+'_'+business_date.strftime('%Y%m%d')
            source+=f'CREATE TABLE IF NOT EXISTS {table} USING st_user_load_96 TAGS ({sqlstr(account)}, {sqlstr(business_date.isoformat())});\n'
    return source


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--accounts',type=Path,default=Path(__file__).with_name('accounts.txt'))
    ap.add_argument('--out',type=Path,default=Path(__file__).parent); ap.add_argument('--target-date',default='2026-10-21')
    ap.add_argument('--days',type=int,default=30); ap.add_argument('--database',default='vpp_resource')
    ap.add_argument('--repo',type=Path,default=Path('/workspace/vpp'))
    args=ap.parse_args(); target=date.fromisoformat(args.target_date)
    assert args.days>=10 and re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_]*',args.database)
    accounts=args.accounts.read_text(encoding='utf-8-sig').split()
    assert len(accounts)==len(set(accounts)), 'Duplicate account numbers'
    assert all(re.fullmatch(r'[A-Za-z0-9_-]{1,64}',x) for x in accounts), 'Unexpected account characters'
    special={x[0]:x for x in SPECS}; assert set(special)<=set(accounts)
    out=args.out; (out/'load').mkdir(parents=True,exist_ok=True); (out/'validation').mkdir(exist_ok=True)
    if args.accounts.resolve()!= (out/'accounts.txt').resolve(): shutil.copyfile(args.accounts,out/'accounts.txt')
    start=target-timedelta(days=args.days-1); previous=workdays_before(target)
    (out/'00_TDengine_建表.sql').write_text(single_line_sql(schema_sql(accounts,args.database,args.repo,start,args.days)),encoding='utf-8')
    ordinary={}; sources={}; tables={}
    for index,account in enumerate(accounts):
        tables[account]='fixture_load_'+hashlib.sha256(account.encode()).hexdigest()[:24]
        sources[account]=None if account=='3750016959549' else 'MANUAL' if account in special else ['DEVICE','STATION','STAKE','MANUAL'][index%4]
        base=D('2')+D(index%32)/4
        for weekend in (False,True):
            ordinary[account,weekend]=[(base+(D('1') if 25<=slot<=40 else D('2') if 41<=slot<=68 else D('1.5') if 69<=slot<=88 else D('0')))*(D('.75') if weekend else D('1')) for slot in range(1,97)]
    total=0; nulls=0; day_stats=[]
    validation=(out/'validation'/'case_loads.csv').open('w',newline='',encoding='utf-8'); writer=csv.writer(validation)
    writer.writerow(['cons_no','data_date','slot_no','load_mw','src_type'])
    for offset in range(args.days):
        business_date=start+timedelta(days=offset); dstr=business_date.isoformat(); weekend=business_date.weekday()>=5
        stamps=[(datetime.combine(business_date,time())+timedelta(minutes=slot*15)).strftime('%Y-%m-%d %H:%M:%S.000') for slot in range(1,97)]
        day_nulls=0
        with (out/'load'/f'{dstr}.sql').open('w',encoding='utf-8') as f:
            f.write(f'-- Business date {dstr}; slot96 timestamp is next midnight.\nUSE {args.database};\n')
            for account in accounts:
                values=[]; src=sources[account]
                for slot in range(1,97):
                    value=special_load(account,business_date,slot,target,previous) if account in special else ordinary[account,weekend][slot-1]
                    day_nulls+=value is None
                    values.append(f'({sqlstr(stamps[slot-1])},{fmt(value)},{sqlstr(src)})')
                    if account in special:writer.writerow([account,dstr,slot,'' if value is None else str(value),'' if src is None else src])
                f.write(f'INSERT INTO {tables[account]}_{business_date.strftime("%Y%m%d")} (ts,load_mw,src_type) VALUES '+' '.join(values)+';\n')
        count=len(accounts)*96; total+=count; nulls+=day_nulls
        day_stats.append(dict(data_date=dstr,rows=count,null_load_rows=day_nulls))
    validation.close()
    expected=[]
    for account,code,label,b0,n,fitted,removed,k,final,actual_mean,baseline_mean in SPECS:
        initial='NO_BASELINE' if b0 is None else 'WAITING' if removed else 'NOT_REQUIRED'
        final_status=initial if not removed else 'UNCORRECTABLE' if k is None else 'CORRECTED'
        expected.append(dict(case=code,cons_no=account,business_date=target.isoformat(),slot_no=41,target_time=target.isoformat()+' 10:15:00',scenario=label,sample_count=n,fitted_count=fitted,removed_count=removed,b0=b0,initial_status=initial,final_status=final_status,k=k,final_baseline=final,actual_mean=actual_mean,baseline_mean=baseline_mean))
    extra=[dict(expected[0],case='S01-MIDNIGHT',slot_no=1,target_time=target.isoformat()+' 00:15:00',scenario='跨日窗口；无昨日基线时初始化16点',sample_count=5,fitted_count=0,removed_count=1,b0='10',initial_status='WAITING',final_status='CORRECTED',k='1',final_baseline='10',actual_mean='10',baseline_mean='10'),dict(expected[8],case='S09-ROLLING',slot_no=42,target_time=target.isoformat()+' 10:30:00',scenario='窗口使用10:15修正后12，均值10.125',k='1.185185',final_baseline='11.851851',actual_mean='12',baseline_mean='10.125')]
    expected+=extra
    # Rest-day selector check: S01 has 20 MW on all ordinary weekend historical points.
    rest_target=target-timedelta(days=1)
    while rest_target.weekday()!=6:rest_target-=timedelta(days=1)
    expected.append(dict(expected[0],case='S01-REST',business_date=rest_target.isoformat(),target_time=rest_target.isoformat()+' 10:15:00',scenario='公休日独立选样，实际日期和样本数以库内日历为准',sample_count=None,fitted_count=None,removed_count=0,b0='20',initial_status='NOT_REQUIRED',final_status='NOT_REQUIRED',k=None,final_baseline='20'))
    (out/'expected_cases.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'预期结果.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=expected[0].keys());w.writeheader();w.writerows(expected)
    (out/'生成统计.json').write_text(json.dumps(dict(database=args.database,target_date=str(target),start_date=str(start),end_date=str(target),account_count=len(accounts),days=args.days,child_table_count=len(accounts)*args.days,physical_rows=total,nonnull_load_rows=total-nulls,null_load_rows=nulls,previous_five_weekdays=[str(x) for x in previous],days_detail=day_stats),ensure_ascii=False,indent=2),encoding='utf-8')
    quoted=','.join(sqlstr(s[0]) for s in SPECS)
    preflight=f"""-- Read only, run on the application's MySQL database.
SELECT cons_no,unit_id,status,deleted FROM ra_aggregate_user WHERE cons_no IN ({quoted}) ORDER BY cons_no;
SELECT calendar_date,day_type FROM ra_calendar_day WHERE deleted=0 AND calendar_date<'{target}' AND day_type='WORKDAY' ORDER BY calendar_date DESC LIMIT 30;
SELECT calendar_date,day_type FROM ra_calendar_day WHERE deleted=0 AND calendar_date<'{rest_target}' AND day_type='RESTDAY' ORDER BY calendar_date DESC LIMIT 20;
SELECT u.cons_no,u.unit_id,a.adjust_date,a.participate FROM ra_aggregate_user u JOIN ra_adjustment_day a ON a.unit_id=u.unit_id WHERE u.cons_no IN ({quoted}) AND a.adjust_date>='{start}' AND a.adjust_date<'{target}' AND a.participate=1 AND a.deleted=0 ORDER BY u.cons_no,a.adjust_date;
"""
    (out/'01_MySQL_前置检查.sql').write_text(preflight,encoding='utf-8')
    verify=f"""-- Read only, TDengine. All physical points are inserted; a NULL load is treated as missing by the program.
SELECT COUNT(*) FROM {args.database}.st_user_load_96;
-- Expected {total}
SELECT COUNT(load_mw) FROM {args.database}.st_user_load_96;
-- Expected {total-nulls}
SELECT COUNT(*) FROM {args.database}.st_user_load_96 WHERE load_mw IS NULL;
-- Expected {nulls}
SELECT COUNT(*) FROM {args.database}.st_user_load_96 WHERE data_date='{target}';
-- Expected {len(accounts)*96}
SELECT ts,cons_no,load_mw,src_type,data_date FROM {args.database}.st_user_load_96 WHERE cons_no='3750016959542' AND ts>='{target} 07:15:00' AND ts<='{target} 07:45:00' ORDER BY ts;
-- 07:15=8, 07:30=NULL, 07:45=16.
"""
    (out/'02_TDengine_导入核验.sql').write_text(verify,encoding='utf-8')
    verify_mysql=f"""-- Read only; run after generating {target}, then processing due correction jobs.
SELECT cons_no,slot_no,correction_status,initial_mean_mw,threshold_mw,removed_count,raw_baseline_mw,actual_window_mean_mw,baseline_window_mean_mw,k_value,final_baseline_mw,sync_status,JSON_LENGTH(sample_detail_json) AS sample_count FROM ra_user_baseline_detail WHERE data_date='{target}' AND calc_version='V1' AND deleted=0 AND cons_no IN ({quoted}) AND (slot_no=41 OR (cons_no='3750016959530' AND slot_no=1) OR (cons_no='3750016959538' AND slot_no=42)) ORDER BY cons_no,slot_no;
SELECT cons_no,slot_no,sample_detail_json,removed_sample_json FROM ra_user_baseline_detail WHERE data_date='{target}' AND calc_version='V1' AND deleted=0 AND cons_no IN ('3750016959531','3750016959532','3750016959533','3750016959534','3750016959547','3750016959548') AND slot_no=41 ORDER BY cons_no;
SELECT cons_no,slot_no,actual_window_json,baseline_window_json,calculation_remark FROM ra_user_baseline_detail WHERE data_date='{target}' AND calc_version='V1' AND deleted=0 AND cons_no IN ('3750016959542','3750016959543','3750016959544','3750016959545') AND slot_no=41 ORDER BY cons_no;
SELECT cons_no,slot_no,correction_status,raw_baseline_mw,final_baseline_mw,sample_detail_json FROM ra_user_baseline_detail WHERE data_date='{rest_target}' AND calc_version='V1' AND deleted=0 AND cons_no='3750016959530' AND slot_no=41;
"""
    (out/'03_MySQL_计算结果核验.sql').write_text(verify_mysql,encoding='utf-8')
    readme=f'''# 近30天用户负荷测试 SQL

目标业务日：{target}；数据日期：{start}—{target}，共{args.days}天。
输入名单：{len(accounts)}个不重复户号，全部保留，未擅自筛为893户。
共{total:,}条物理负荷记录，其中非空{total-nulls:,}条、空负荷{nulls:,}条。空负荷通过load_mw=NULL构造，程序查询IS NOT NULL后等同缺点；不使用0伪装缺点。

## 执行顺序

1. 本包SQL直接使用现有TDengine数据库`{args.database}`，不创建新库。先执行`00_TDengine_建表.sql`：按已确认结构创建源超级表（已存在则保留）、结果超级表及{len(accounts)*args.days:,}个按“户号＋业务日期”划分的负荷子表。cons_no NCHAR(40)、data_date NCHAR(10)均为TAG；普通列为ts TIMESTAMP、load_mw DOUBLE、src_type NCHAR(20)。建表使用IF NOT EXISTS，保留已有表结构；不DROP/DELETE实际负荷。已有超级表的列与TAG须和脚本DDL一致，IF NOT EXISTS不会自动修改已有表结构。
2. 按日期执行`load/`内全部{args.days}份SQL，文件均自带USE。每户每天一张固定日期子表、一条包含96组值的单行INSERT；INSERT只写ts、load_mw、src_type，户号和日期从子表TAG读取。每条完整SQL占一行以兼容taos -f，VALUES使用TDengine格式，不使用MySQL存储过程或递归CTE。
3. 程序继续使用现有`td-resource`数据源连接`{args.database}`，无需切换数据库配置；源负荷和基线结果均在此库。MySQL仍需有名单中的有效用户及日历。
4. 执行`01_MySQL_前置检查.sql`：确认20个重点户号有效、主验证日前5个工作日为{', '.join(map(str,previous))}，且所属聚合单元没有影响这些日期的参与标记。该SQL不修改用户、日历或参与记录。无效户号不会被基线任务处理，959个导入户号不一定等于893个有效户号。
5. 执行`02_TDengine_导入核验.sql`；核对记录数量及缺点。
6. 运行`generateDailyUserBaseline`，日期参数填`{target}`或当天留空。确认本轮确实全量重算。再执行分钟修正任务，直到这些已到期重点点位处理完成。未来点到时才处理，本包当日全96点为模拟数据。
7. 执行`03_MySQL_计算结果核验.sql`，对照`预期结果.csv`、`expected_cases.json`。
8. 如需核对公休日，参数填`{rest_target}`另跑一遍，核对S01-REST的20MW及样本日期均为RESTDAY。实际日历可能把国庆、中秋、调休日期排除，所以公休日样本数量不写死为5。

## 边界和前提

- 15分钟点为00:15、00:30……次日00:00；最后一个点所在子表的data_date TAG仍为前一天，导入与程序使用同一业务时区Asia/Shanghai。
- 不生成法定节假日分支的专门期望值，不修改已有日历。不把10月1日等日期擅自改成普通日。默认负荷按星期构造曲线；代码仍按MySQL实际日历选典型日。
- 固定数值期望只在预期工作日、参与状态匹配时成立。历史标记不同而样本换天，不可直接判程序错误；先看sample_detail_json。
- 先找真实值、不足再拟合，因此S02只有缺点不会触发拟合；S03/S04刻意让真实值不足5天。
- S01额外在00:15需要修正。若库内没有昨日基线，走跨日初始化；有昨日基线时直接使用昨日最终值，预期都是K=1、最终10。
- S09的10:30预期使用10:15修正后12：历史窗口均值=(15×10+12)/16=10.125，K=1.185185，最终11.851851。先完成10:15再核对10:30。
- S13的07:30缺点在07:15=8、07:45=16之间取前值8，实际窗口均值11.75；S14的06:15前面4小时均无值，取06:30=14，均值12.25。
- S15查询能使用的实际值全部为空；未来10:30之后有值也不能用来修正10:15，结果为UNCORRECTABLE并保留B0=10。
- S16只在计算K窗口时用前值补基线；07:30原来的NO_BASELINE输出本身不被篡改。
- S12/S15无法修正时，当前代码保存的两个窗口均值字段均为NULL；CSV中的actual_mean/baseline_mean仅解释数学条件，不能要求这些列也写入表。K均为空，最终保留10。
- 未自动构造“参与日补足”，因为参与属于聚合单元，不能按户号乱标记。未声称仅30天数据可完全验证30工作日/20公休日搜索上限；这需要额外更早的边界样本。
- 本包只生成SQL，不连接数据库；没有执行实际插入、覆盖或应用配置修改。重跑相同SQL是同时间戳覆盖，缺点保持NULL的行为需要当前TDengine支持明确NULL覆盖。本包按当前空负荷表准备，重复导入时需核对NULL覆盖行为。

## 子表结构和导入示例

用户已确认`st_user_load_96`有两个TAG，按cons_no、data_date顺序。因此同一子表不能跨业务日期复用：959户×30天=28,770张负荷子表。全部子表DDL在`00_TDengine_建表.sql`中。

```sql
USE vpp_resource;
CREATE TABLE IF NOT EXISTS fixture_load_f94b99aa657f444f9c3b7892_20261021 USING st_user_load_96 TAGS ('SD220-001', '2026-10-21');
INSERT INTO fixture_load_f94b99aa657f444f9c3b7892_20261021 (ts, load_mw, src_type) VALUES ('2026-10-21 00:15:00.000', 2, 'DEVICE');
```

原包在创建负荷子表时即报TAG数量不匹配。请用新版完整解压后的文件重新执行；不需要删除或修改超级表。原包的普通列data_date插入方式已去掉，缺点与异常值数据保持原样。

## 文件说明

- `accounts.txt`：完整原始959户名单。
- `load/*.sql`：按天拆分的可执行TDengine负荷数据。
- `预期结果.csv`/`expected_cases.json`：20个重点户号、23个主要检查点。
- `validation/case_loads.csv`：重点户号完整输入，用于隔离验证。
- `generate_fixture.py`：仅用Python标准库的生成器，可改目标日期、天数、库名重新生成；生成器依赖仓库的结果表DDL。
- `验证报告.txt`：生成后补充的实际检查记录；真实TDengine、MySQL、Spring联调需在你的环境执行。
'''
    (out/'README.md').write_text(readme,encoding='utf-8')
    print(json.dumps(dict(out=str(out),accounts=len(accounts),days=args.days,rows=total,nulls=nulls,case_checks=len(expected)),ensure_ascii=False))

if __name__=='__main__':main()
