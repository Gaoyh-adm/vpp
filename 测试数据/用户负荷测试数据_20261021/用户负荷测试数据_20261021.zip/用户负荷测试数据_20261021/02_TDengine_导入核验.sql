-- Read only, TDengine. All physical points are inserted; a NULL load is treated as missing by the program.
SELECT COUNT(*) FROM vpp_baseline_fixture.st_user_load_96;
-- Expected 2761920
SELECT COUNT(load_mw) FROM vpp_baseline_fixture.st_user_load_96;
-- Expected 2761496
SELECT COUNT(*) FROM vpp_baseline_fixture.st_user_load_96 WHERE load_mw IS NULL;
-- Expected 424
SELECT COUNT(*) FROM vpp_baseline_fixture.st_user_load_96 WHERE data_date='2026-10-21';
-- Expected 92064
SELECT ts,cons_no,load_mw,src_type,data_date FROM vpp_baseline_fixture.st_user_load_96 WHERE cons_no='3750016959542' AND ts>='2026-10-21 07:15:00' AND ts<='2026-10-21 07:45:00' ORDER BY ts;
-- 07:15=8, 07:30=NULL, 07:45=16.
