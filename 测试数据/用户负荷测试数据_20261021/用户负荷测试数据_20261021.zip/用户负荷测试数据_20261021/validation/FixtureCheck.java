import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
/** 按已确认优先级为单户单点选择典型日样本。 */

class TypicalSampleSelector {

    private static final int MAX_SAMPLES = 5;
    private static final int WORKDAY_SCOPE = 30;
    private static final int RESTDAY_SCOPE = 20;

    public List<TypicalSampleTrace> select(BaselineCalendarDay targetDay,
                                           List<BaselineCalendarDay> historyDaysDesc,
                                           Set<LocalDate> participationDates,
                                           Map<LocalDate, Map<Integer, UserLoadPoint>> loadsByDate,
                                           int slotNo) {
        if (UserBaselineConstants.DAY_HOLIDAY.equals(targetDay.getDayType())) {
            return selectHoliday(targetDay, historyDaysDesc, participationDates, loadsByDate, slotNo);
        }
        int scopeSize = UserBaselineConstants.DAY_WORKDAY.equals(targetDay.getDayType())
                ? WORKDAY_SCOPE : RESTDAY_SCOPE;
        List<BaselineCalendarDay> scope = historyDaysDesc.stream()
                .filter(day -> targetDay.getDayType().equals(day.getDayType()))
                .limit(scopeSize)
                .toList();
        return selectOrdinary(scope, participationDates, loadsByDate, slotNo, MAX_SAMPLES);
    }

    private List<TypicalSampleTrace> selectOrdinary(List<BaselineCalendarDay> scope,
                                                    Set<LocalDate> participationDates,
                                                    Map<LocalDate, Map<Integer, UserLoadPoint>> loadsByDate,
                                                    int slotNo,
                                                    int maxSamples) {
        List<BaselineCalendarDay> normalDays = scope.stream()
                .filter(day -> !participationDates.contains(day.getCalendarDate()))
                .toList();
        List<BaselineCalendarDay> participationDays = scope.stream()
                .filter(day -> participationDates.contains(day.getCalendarDate()))
                .toList();

        List<TypicalSampleTrace> result = new ArrayList<>();
        appendActual(result, normalDays, loadsByDate, slotNo, "正常真实值", maxSamples);
        appendFitted(result, normalDays, scope, loadsByDate, slotNo, "正常拟合值", maxSamples);
        appendActual(result, participationDays, loadsByDate, slotNo, "参与日真实值", maxSamples);
        appendFitted(result, participationDays, scope, loadsByDate, slotNo, "参与日拟合值", maxSamples);
        return result;
    }

    private List<TypicalSampleTrace> selectHoliday(BaselineCalendarDay targetDay,
                                                   List<BaselineCalendarDay> historyDaysDesc,
                                                   Set<LocalDate> participationDates,
                                                   Map<LocalDate, Map<Integer, UserLoadPoint>> loadsByDate,
                                                   int slotNo) {
        String targetGroup = holidayGroup(targetDay);
        List<BaselineCalendarDay> lastYearCandidates = historyDaysDesc.stream()
                .filter(day -> UserBaselineConstants.DAY_HOLIDAY.equals(day.getDayType()))
                .filter(day -> day.getCalendarDate().getYear() == targetDay.getCalendarDate().getYear() - 1)
                .filter(day -> sharesHolidayType(targetDay, day))
                .toList();
        List<BaselineCalendarDay> lastYearSameHoliday = filterTargetCombinedHolidayDates(
                targetDay, lastYearCandidates);

        List<List<BaselineCalendarDay>> groups = new ArrayList<>();
        if (!lastYearSameHoliday.isEmpty()) {
            groups.add(lastYearSameHoliday);
        }
        Map<String, List<BaselineCalendarDay>> otherGroups = new LinkedHashMap<>();
        historyDaysDesc.stream()
                .filter(day -> UserBaselineConstants.DAY_HOLIDAY.equals(day.getDayType()))
                .filter(day -> day.getCalendarDate().getYear() == targetDay.getCalendarDate().getYear())
                .filter(day -> !targetGroup.equals(holidayGroup(day)))
                .forEach(day -> otherGroups.computeIfAbsent(holidayGroup(day), ignored -> new ArrayList<>()).add(day));
        groups.addAll(otherGroups.values().stream()
                .sorted(Comparator.comparing((List<BaselineCalendarDay> days) ->
                        days.get(0).getCalendarDate()).reversed())
                .toList());

        List<BaselineCalendarDay> allHolidayDays = historyDaysDesc.stream()
                .filter(day -> UserBaselineConstants.DAY_HOLIDAY.equals(day.getDayType()))
                .toList();
        List<BaselineCalendarDay> fittingSourceDays = allHolidayDays.stream()
                .sorted(Comparator.comparing(BaselineCalendarDay::getCalendarDate).reversed())
                .toList();
        for (List<BaselineCalendarDay> group : groups) {
            List<BaselineCalendarDay> usableDays = group.stream()
                    .filter(day -> !participationDates.contains(day.getCalendarDate()))
                    .filter(day -> loadsByDate.containsKey(day.getCalendarDate()))
                    .toList();
            List<TypicalSampleTrace> samples = new ArrayList<>();
            appendActual(samples, usableDays, loadsByDate, slotNo, "节假日真实值", Integer.MAX_VALUE);
            appendFitted(samples, usableDays, fittingSourceDays, loadsByDate, slotNo,
                    "节假日拟合值", Integer.MAX_VALUE);
            if (!samples.isEmpty()) {
                return samples;
            }
        }

        List<BaselineCalendarDay> restScope = historyDaysDesc.stream()
                .filter(day -> UserBaselineConstants.DAY_RESTDAY.equals(day.getDayType()))
                .limit(RESTDAY_SCOPE)
                .toList();
        return selectOrdinary(restScope, participationDates, loadsByDate, slotNo, MAX_SAMPLES);
    }

    private void appendActual(List<TypicalSampleTrace> result,
                              List<BaselineCalendarDay> targetDays,
                              Map<LocalDate, Map<Integer, UserLoadPoint>> loadsByDate,
                              int slotNo,
                              String category,
                              int maxSamples) {
        Set<LocalDate> existingTargets = existingTargets(result);
        for (BaselineCalendarDay day : targetDays) {
            if (result.size() >= maxSamples || existingTargets.contains(day.getCalendarDate())) {
                continue;
            }
            UserLoadPoint point = loadsByDate.getOrDefault(day.getCalendarDate(), Map.of()).get(slotNo);
            if (point != null && point.getLoadMw() != null) {
                result.add(new TypicalSampleTrace(day.getCalendarDate(), day.getCalendarDate(), slotNo,
                        point.getLoadMw(), category, false, chineseSourceType(point.getSrcType())));
                existingTargets.add(day.getCalendarDate());
            }
        }
    }

    private void appendFitted(List<TypicalSampleTrace> result,
                              List<BaselineCalendarDay> targetDays,
                              List<BaselineCalendarDay> sourceScope,
                              Map<LocalDate, Map<Integer, UserLoadPoint>> loadsByDate,
                              int slotNo,
                              String category,
                              int maxSamples) {
        Set<LocalDate> existingTargets = existingTargets(result);
        for (BaselineCalendarDay targetDay : targetDays) {
            if (result.size() >= maxSamples || existingTargets.contains(targetDay.getCalendarDate())) {
                continue;
            }
            UserLoadPoint direct = loadsByDate.getOrDefault(targetDay.getCalendarDate(), Map.of()).get(slotNo);
            if (direct != null && direct.getLoadMw() != null) {
                continue;
            }
            for (BaselineCalendarDay sourceDay : sourceScope) {
                if (!sourceDay.getCalendarDate().isBefore(targetDay.getCalendarDate())) {
                    continue;
                }
                UserLoadPoint source = loadsByDate.getOrDefault(sourceDay.getCalendarDate(), Map.of()).get(slotNo);
                if (source != null && source.getLoadMw() != null) {
                    result.add(new TypicalSampleTrace(targetDay.getCalendarDate(), sourceDay.getCalendarDate(),
                            slotNo, source.getLoadMw(), category, true, chineseSourceType(source.getSrcType())));
                    existingTargets.add(targetDay.getCalendarDate());
                    break;
                }
            }
        }
    }

    private Set<LocalDate> existingTargets(List<TypicalSampleTrace> result) {
        Set<LocalDate> dates = new LinkedHashSet<>();
        result.forEach(sample -> dates.add(sample.targetDate()));
        return dates;
    }

    private String holidayGroup(BaselineCalendarDay day) {
        if (day.getHolidayGroupCode() != null && !day.getHolidayGroupCode().isBlank()) {
            return day.getHolidayGroupCode();
        }
        if (day.getHolidayCode() != null && !day.getHolidayCode().isBlank()) {
            return day.getHolidayCode();
        }
        return day.getHolidayName() == null ? day.getCalendarDate().toString() : day.getHolidayName();
    }

    private boolean sharesHolidayType(BaselineCalendarDay targetDay, BaselineCalendarDay sourceDay) {
        Set<String> targetTypes = holidayTypes(targetDay);
        Set<String> sourceTypes = holidayTypes(sourceDay);
        if (!targetTypes.isEmpty() && !sourceTypes.isEmpty()) {
            return targetTypes.stream().anyMatch(sourceTypes::contains);
        }
        return holidayGroup(targetDay).equals(holidayGroup(sourceDay));
    }

    private boolean isExcludedMidAutumnDate(BaselineCalendarDay sourceDay) {
        Set<String> sourceTypes = holidayTypes(sourceDay);
        if (!containsNationalDay(sourceTypes)
                || !containsMidAutumn(sourceTypes)) {
            return false;
        }
        return containsMidAutumn(splitCodes(sourceDay.getFestivalTags()));
    }

    private List<BaselineCalendarDay> filterTargetCombinedHolidayDates(BaselineCalendarDay targetDay,
                                                                        List<BaselineCalendarDay> sourceDays) {
        Set<String> targetTypes = holidayTypes(targetDay);
        // 只有当年国庆、中秋分开且上一年合并时，才剔除上一年国庆候选日中的中秋当天。
        if (!containsNationalDay(targetTypes) || containsMidAutumn(targetTypes)) {
            return sourceDays.stream()
                    .sorted(Comparator.comparing(BaselineCalendarDay::getCalendarDate).reversed())
                    .toList();
        }
        Map<String, List<BaselineCalendarDay>> groups = sourceDays.stream()
                .collect(java.util.stream.Collectors.groupingBy(this::holidayGroup,
                        LinkedHashMap::new, java.util.stream.Collectors.toList()));
        List<BaselineCalendarDay> result = new ArrayList<>();
        for (List<BaselineCalendarDay> group : groups.values()) {
            boolean combined = group.stream().map(this::holidayTypes)
                    .anyMatch(types -> containsNationalDay(types) && containsMidAutumn(types));
            if (combined && group.stream().noneMatch(day ->
                    containsMidAutumn(splitCodes(day.getFestivalTags())))) {
                continue;
            }
            group.stream().filter(day -> !isExcludedMidAutumnDate(day)).forEach(result::add);
        }
        return result.stream()
                .sorted(Comparator.comparing(BaselineCalendarDay::getCalendarDate).reversed())
                .toList();
    }

    private Set<String> holidayTypes(BaselineCalendarDay day) {
        Set<String> result = splitCodes(day.getHolidayCode());
        if (result.isEmpty() && day.getHolidayName() != null) {
            result = splitCodes(day.getHolidayName());
        }
        return result;
    }

    private Set<String> splitCodes(String value) {
        if (value == null || value.isBlank()) {
            return Set.of();
        }
        Set<String> result = new LinkedHashSet<>();
        for (String item : value.split("[,，、]")) {
            if (!item.isBlank()) {
                result.add(item.trim());
            }
        }
        return result;
    }

    private boolean containsNationalDay(Set<String> values) {
        return values.contains(UserBaselineConstants.HOLIDAY_NATIONAL_DAY) || values.contains("国庆节");
    }

    private boolean containsMidAutumn(Set<String> values) {
        return values.contains(UserBaselineConstants.HOLIDAY_MID_AUTUMN) || values.contains("中秋节");
    }

    private String chineseSourceType(String sourceType) {
        if (sourceType == null || sourceType.isBlank()) {
            return "负荷来源类型未标注";
        }
        return switch (sourceType.trim().toUpperCase()) {
            case "DEVICE" -> "设备负荷汇总";
            case "STATION" -> "场站负荷汇总";
            case "STAKE" -> "充电桩负荷汇总";
            case "MANUAL" -> "人工维护负荷";
            default -> "负荷来源代码“" + sourceType + "”";
        };
    }
}

/** 用户基线纯计算器，不访问数据库。 */

class UserBaselinePointCalculator {

    private static final MathContext CALC_CONTEXT = MathContext.DECIMAL128;
    private static final BigDecimal HIGH_VALUE_FACTOR = new BigDecimal("1.5");

    /** 计算原始基线，并标识是否实际发生异常高值剔除。 */
    public RawBaselineResult calculateRaw(List<TypicalSampleTrace> inputSamples) {
        List<TypicalSampleTrace> samples = inputSamples == null
                ? List.of()
                : inputSamples.stream().filter(sample -> sample != null && sample.value() != null).toList();
        if (samples.isEmpty()) {
            return new RawBaselineResult(null, null, null, null, List.of(), List.of(),
                    UserBaselineConstants.STATUS_NO_BASELINE,
                    "该点未取得有效典型日样本，无法生成原始基线。");
        }

        BigDecimal initialMean = mean(samples.stream().map(TypicalSampleTrace::value).toList());
        BigDecimal threshold = initialMean.multiply(HIGH_VALUE_FACTOR, CALC_CONTEXT);
        List<TypicalSampleTrace> removed = samples.stream()
                .filter(sample -> sample.value().compareTo(BigDecimal.ZERO) > 0
                        && sample.value().compareTo(threshold) > 0)
                .toList();
        List<TypicalSampleTrace> retained = new ArrayList<>(samples);
        retained.removeAll(removed);
        if (retained.isEmpty()) {
            return new RawBaselineResult(initialMean, threshold, null, null, samples, removed,
                    UserBaselineConstants.STATUS_NO_BASELINE,
                    "异常高值剔除后没有剩余样本，无法生成原始基线。");
        }

        BigDecimal rawCalculation = mean(retained.stream().map(TypicalSampleTrace::value).toList());
        BigDecimal rawBaseline = truncate6(rawCalculation);
        String sampleDates = samples.stream()
                .map(sample -> sample.targetDate() + "=" + truncate6(sample.value()).toPlainString())
                .collect(Collectors.joining("，"));
        String remark;
        String status;
        if (removed.isEmpty()) {
            status = UserBaselineConstants.STATUS_NOT_REQUIRED;
            remark = "该点取得" + samples.size() + "个典型日样本（" + sampleDates + "），初始平均负荷为"
                    + truncate6(initialMean).toPlainString() + "兆瓦，异常高值阈值为"
                    + truncate6(threshold).toPlainString()
                    + "兆瓦；未发生异常高值剔除，不需要进行实时修正，最终基线等于原始基线"
                    + rawBaseline.toPlainString() + "兆瓦，K值为空。";
        } else {
            status = UserBaselineConstants.STATUS_WAITING;
            String removedText = removed.stream()
                    .map(sample -> sample.targetDate() + "=" + truncate6(sample.value()).toPlainString() + "兆瓦")
                    .collect(Collectors.joining("，"));
            remark = "该点取得" + samples.size() + "个典型日样本（" + sampleDates + "），初始平均负荷为"
                    + truncate6(initialMean).toPlainString() + "兆瓦，异常高值阈值为"
                    + truncate6(threshold).toPlainString() + "兆瓦；剔除异常高值样本：" + removedText
                    + "。使用剩余" + retained.size() + "个样本计算原始基线为"
                    + rawBaseline.toPlainString() + "兆瓦，该点需要在目标时刻计算K值并修正。";
        }
        return new RawBaselineResult(initialMean, threshold, rawCalculation, rawBaseline,
                samples, removed, status, remark);
    }

    /** 计算K和最终基线；窗口补值由调用方完成。 */
    public CorrectionResult calculateCorrection(BigDecimal rawCalculationValue,
                                                BigDecimal savedRawBaseline,
                                                List<WindowValueTrace> actualWindow,
                                                List<WindowValueTrace> baselineWindow) {
        if (actualWindow == null || actualWindow.size() != UserBaselineConstants.WINDOW_POINTS) {
            return uncorrectable(savedRawBaseline, actualWindow, baselineWindow,
                    "前4小时实际负荷窗口无法补齐，K值为空，最终基线保留原始基线"
                            + savedRawBaseline.toPlainString() + "兆瓦。");
        }
        if (baselineWindow == null || baselineWindow.size() != UserBaselineConstants.WINDOW_POINTS) {
            return uncorrectable(savedRawBaseline, actualWindow, baselineWindow,
                    "前4小时历史最终基线窗口无法补齐，K值为空，最终基线保留原始基线"
                            + savedRawBaseline.toPlainString() + "兆瓦。");
        }

        BigDecimal actualMeanRaw = mean(actualWindow.stream().map(WindowValueTrace::value).toList());
        BigDecimal baselineMeanRaw = mean(baselineWindow.stream().map(WindowValueTrace::value).toList());
        if (baselineMeanRaw.compareTo(BigDecimal.ZERO) == 0) {
            return uncorrectable(savedRawBaseline, actualWindow, baselineWindow,
                    "前4小时历史最终基线平均负荷为0，不能作为K值分母；K值为空，最终基线保留原始基线"
                            + savedRawBaseline.toPlainString() + "兆瓦。");
        }

        BigDecimal kCalculation = actualMeanRaw.divide(baselineMeanRaw, CALC_CONTEXT);
        BigDecimal finalCalculation = rawCalculationValue.multiply(kCalculation, CALC_CONTEXT);
        BigDecimal actualMean = truncate6(actualMeanRaw);
        BigDecimal baselineMean = truncate6(baselineMeanRaw);
        BigDecimal kValue = truncate6(kCalculation);
        BigDecimal finalBaseline = truncate6(finalCalculation);
        String remark = "前4小时16个实际负荷点平均值为" + actualMean.toPlainString()
                + "兆瓦，前4小时16个历史最终基线点平均值为" + baselineMean.toPlainString()
                + "兆瓦；K计算值=" + actualMeanRaw.toPlainString() + "÷"
                + baselineMeanRaw.toPlainString() + "，保存K值为" + kValue.toPlainString()
                + "；原始基线计算值为" + rawCalculationValue.toPlainString()
                + "兆瓦，修正后基线为" + finalBaseline.toPlainString() + "兆瓦。";
        return new CorrectionResult(UserBaselineConstants.STATUS_CORRECTED, actualMean,
                baselineMean, kValue, finalBaseline, actualWindow, baselineWindow, remark);
    }

    public BigDecimal truncate6(BigDecimal value) {
        return value == null ? null : value.setScale(6, RoundingMode.DOWN);
    }

    private CorrectionResult uncorrectable(BigDecimal rawBaseline,
                                           List<WindowValueTrace> actualWindow,
                                           List<WindowValueTrace> baselineWindow,
                                           String remark) {
        return new CorrectionResult(UserBaselineConstants.STATUS_UNCORRECTABLE, null, null,
                null, rawBaseline, actualWindow, baselineWindow, remark);
    }

    private BigDecimal mean(List<BigDecimal> values) {
        BigDecimal sum = values.stream().reduce(BigDecimal.ZERO,
                (left, right) -> left.add(right, CALC_CONTEXT));
        return sum.divide(BigDecimal.valueOf(values.size()), CALC_CONTEXT);
    }
}


/** 用户基线精度、追踪码和TDengine子表名转换。 */

class UserBaselineStorageSupport {

    private static final BigDecimal SCALE_FACTOR = new BigDecimal("1000000");

    public Long toScaledLong(BigDecimal value) {
        if (value == null) {
            return null;
        }
        return value.setScale(6, RoundingMode.DOWN).multiply(SCALE_FACTOR).longValueExact();
    }

    public BigDecimal fromScaledLong(Long value) {
        return value == null ? null : BigDecimal.valueOf(value, 6);
    }

    public LocalDateTime slotTime(LocalDate dataDate, int slotNo) {
        if (slotNo < 1 || slotNo > UserBaselineConstants.POINTS_PER_DAY) {
            throw new IllegalArgumentException("点序号必须在1至96之间");
        }
        return LocalDateTime.of(dataDate, LocalTime.MIDNIGHT).plusMinutes(slotNo * 15L);
    }

    public int slotOf(LocalDate dataDate, LocalDateTime timestamp) {
        if (dataDate == null || timestamp == null) {
            return 0;
        }
        LocalDateTime dayStart = dataDate.atStartOfDay();
        long minutes = java.time.Duration.between(dayStart, timestamp).toMinutes();
        if (minutes == 0 && timestamp.toLocalDate().isAfter(dataDate)) {
            minutes = 24L * 60L;
        }
        if (minutes == 0 && timestamp.toLocalDate().equals(dataDate)) {
            return UserBaselineConstants.POINTS_PER_DAY;
        }
        if (minutes < 15 || minutes > 24L * 60L || minutes % 15 != 0) {
            return 0;
        }
        return (int) (minutes / 15);
    }

    public String tableName(String consNo) {
        String digest = sha256(consNo).substring(0, 24);
        return "user_baseline_" + digest;
    }

    public String traceCode(String consNo, LocalDate dataDate, int slotNo, String calcVersion) {
        return sha256(consNo + "|" + dataDate + "|" + slotNo + "|" + calcVersion);
    }

    public void validateTableName(String tableName) {
        if (tableName == null || !tableName.matches("user_baseline_[0-9a-f]{24}")) {
            throw new IllegalArgumentException("用户基线TDengine子表名不合法");
        }
    }

    private String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("当前JDK不支持SHA-256", e);
        }
    }
}

/** 用户基线固定业务值。 */
final class UserBaselineConstants {

    public static final String DAY_WORKDAY = "WORKDAY";
    public static final String DAY_RESTDAY = "RESTDAY";
    public static final String DAY_HOLIDAY = "HOLIDAY";

    public static final String STATUS_NO_BASELINE = "NO_BASELINE";
    public static final String STATUS_NOT_REQUIRED = "NOT_REQUIRED";
    public static final String STATUS_WAITING = "WAITING";
    public static final String STATUS_CORRECTED = "CORRECTED";
    public static final String STATUS_UNCORRECTABLE = "UNCORRECTABLE";

    public static final String SYNC_PENDING = "PENDING";
    public static final String SYNCED = "SYNCED";

    public static final String HOLIDAY_NATIONAL_DAY = "NATIONAL_DAY";
    public static final String HOLIDAY_MID_AUTUMN = "MID_AUTUMN";

    public static final String TASK_PENDING = "PENDING";
    public static final String TASK_PROCESSING = "PROCESSING";
    public static final String TASK_RETRY_WAIT = "RETRY_WAIT";
    public static final String TASK_SUCCESS = "SUCCESS";

    public static final int POINTS_PER_DAY = 96;
    public static final int WINDOW_POINTS = 16;

    private UserBaselineConstants() {
    }
}

/** 单户单点原始基线计算结果。 */
record RawBaselineResult(
        BigDecimal initialMean,
        BigDecimal threshold,
        BigDecimal rawCalculationValue,
        BigDecimal rawBaseline,
        List<TypicalSampleTrace> samples,
        List<TypicalSampleTrace> removedSamples,
        String status,
        String chineseRemark) {

    public boolean hasRemovedSample() {
        return removedSamples != null && !removedSamples.isEmpty();
    }
}


/** 参与原始基线计算的一个典型日样本。 */
record TypicalSampleTrace(
        LocalDate targetDate,
        LocalDate sourceDate,
        int slotNo,
        BigDecimal value,
        String sourceCategory,
        boolean fitted,
        String sourceType) {
}


/** K值窗口中一个目标点的实际取值及来源。 */
record WindowValueTrace(
        LocalDateTime targetTime,
        LocalDateTime sourceTime,
        BigDecimal value,
        String sourceDescription,
        String direction,
        int distanceMinutes) {
}


/** 单户单点K值修正结果。 */
record CorrectionResult(
        String status,
        BigDecimal actualMean,
        BigDecimal baselineMean,
        BigDecimal kValue,
        BigDecimal finalBaseline,
        List<WindowValueTrace> actualWindow,
        List<WindowValueTrace> baselineWindow,
        String chineseRemark) {
}


/**
 * 首次启动时按完整历史时点计算并保存的原始基线种子。
 *
 * @param pointTime 完整历史时点
 * @param dataDate 历史时点所属业务日期
 * @param slotNo 历史时点所属点序号
 * @param rawResult 该历史点完整的B0计算结果及来源
 */
record InitialBaselineSeed(
        LocalDateTime pointTime,
        LocalDate dataDate,
        int slotNo,
        RawBaselineResult rawResult) {
}

class BaselineCalendarDay {
 LocalDate d; String type; BaselineCalendarDay(LocalDate d){this.d=d;type=d.getDayOfWeek().getValue()<6?"WORKDAY":"RESTDAY";}
 LocalDate getCalendarDate(){return d;} String getDayType(){return type;}
 String getHolidayGroupCode(){return null;} String getHolidayCode(){return null;} String getHolidayName(){return null;} String getFestivalTags(){return null;}
}
class UserLoadPoint { BigDecimal v;String src; UserLoadPoint(String v,String src){this.v=new BigDecimal(v);this.src=src;}BigDecimal getLoadMw(){return v;}String getSrcType(){return src;} }
class UserBaselineLoad {Long v;String status;UserBaselineLoad(BigDecimal v,String s){this.v=new UserBaselineStorageSupport().toScaledLong(v);status=s;} Long getFinalBaselineE6(){return v;}String getCorrectionStatus(){return status;}String getConsNo(){return "fixture";} }
class Windows { UserBaselineStorageSupport storageSupport=new UserBaselineStorageSupport();
    private WindowBuild buildActualWindow(LocalDateTime targetTime,
                                          Map<LocalDateTime, UserLoadPoint> source) {
        List<WindowValueTrace> result = new ArrayList<>(UserBaselineConstants.WINDOW_POINTS);
        for (int i = UserBaselineConstants.WINDOW_POINTS; i >= 1; i--) {
            LocalDateTime pointTime = targetTime.minusMinutes(i * 15L);
            UserLoadPoint direct = source.get(pointTime);
            if (direct != null && direct.getLoadMw() != null) {
                result.add(new WindowValueTrace(pointTime, pointTime, direct.getLoadMw(),
                        "采用目标时点真实负荷，来源类型：" + chineseSource(direct.getSrcType()), "当前点", 0));
                continue;
            }
            WindowValueTrace fitted = null;
            for (int distance = 15; distance <= 240 && fitted == null; distance += 15) {
                LocalDateTime previous = pointTime.minusMinutes(distance);
                UserLoadPoint previousValue = source.get(previous);
                if (previousValue != null && previousValue.getLoadMw() != null) {
                    fitted = new WindowValueTrace(pointTime, previous, previousValue.getLoadMw(),
                            "目标时点缺失，采用前方已有真实负荷，来源类型："
                                    + chineseSource(previousValue.getSrcType()), "前值", distance);
                    break;
                }
                LocalDateTime next = pointTime.plusMinutes(distance);
                if (!next.isAfter(targetTime)) {
                    UserLoadPoint nextValue = source.get(next);
                    if (nextValue != null && nextValue.getLoadMw() != null) {
                        fitted = new WindowValueTrace(pointTime, next, nextValue.getLoadMw(),
                                "目标时点缺失，采用后方已有真实负荷，来源类型："
                                        + chineseSource(nextValue.getSrcType()), "后值", distance);
                    }
                }
            }
            if (fitted == null) {
                return new WindowBuild(result, pointTime);
            }
            result.add(fitted);
        }
        return new WindowBuild(result, null);
    }
    private WindowBuild buildBaselineWindow(LocalDateTime targetTime,
                                             Map<LocalDateTime, UserBaselineLoad> source,
                                             Map<LocalDateTime, InitialBaselineSeed> seeds) {
        List<WindowValueTrace> result = new ArrayList<>(UserBaselineConstants.WINDOW_POINTS);
        for (int i = UserBaselineConstants.WINDOW_POINTS; i >= 1; i--) {
            LocalDateTime pointTime = targetTime.minusMinutes(i * 15L);
            UserBaselineLoad direct = source.get(pointTime);
            if (direct != null && UserBaselineConstants.STATUS_WAITING.equals(direct.getCorrectionStatus())) {
                throw new IllegalStateException("户号" + direct.getConsNo() + "的历史点" + pointTime
                        + "仍等待修正，当前点必须在前一点完成后再计算。");
            }
            if (direct != null && direct.getFinalBaselineE6() != null) {
                result.add(new WindowValueTrace(pointTime, pointTime,
                        storageSupport.fromScaledLong(direct.getFinalBaselineE6()),
                        "采用该历史时点已输出的最终基线", "当前点", 0));
                continue;
            }
            Map.Entry<LocalDateTime, UserBaselineLoad> previousPublished = source.entrySet().stream()
                    .filter(entry -> entry.getKey().isBefore(pointTime))
                    .filter(entry -> entry.getValue().getFinalBaselineE6() != null)
                    .filter(entry -> !UserBaselineConstants.STATUS_WAITING.equals(
                            entry.getValue().getCorrectionStatus()))
                    .max(Map.Entry.comparingByKey())
                    .orElse(null);
            InitialBaselineSeed seed = seeds.get(pointTime);
            boolean exactSeedUsable = seed != null && seed.rawResult() != null
                    && seed.rawResult().rawBaseline() != null;
            if (exactSeedUsable && previousPublished != null) {
                UserBaselineLoad previous = previousPublished.getValue();
                LocalDateTime previousTime = previousPublished.getKey();
                int distance = Math.toIntExact(java.time.Duration.between(previousTime, pointTime).toMinutes());
                result.add(new WindowValueTrace(pointTime, previousTime,
                        storageSupport.fromScaledLong(previous.getFinalBaselineE6()),
                        "历史最终基线缺失，采用最近有效前值", "前值", distance));
                continue;
            }
            if (exactSeedUsable) {
                result.add(new WindowValueTrace(pointTime, seed.pointTime(), seed.rawResult().rawBaseline(),
                        "首次启动缺少历史最终基线，采用历史业务日期" + seed.dataDate() + "第"
                                + seed.slotNo() + "点单独计算并保存的B0；" + seed.rawResult().chineseRemark(),
                        "初始化种子", 0));
                continue;
            }
            Map.Entry<LocalDateTime, InitialBaselineSeed> previousSeed = seeds.entrySet().stream()
                    .filter(entry -> entry.getKey().isBefore(pointTime))
                    .filter(entry -> entry.getValue() != null && entry.getValue().rawResult() != null)
                    .filter(entry -> entry.getValue().rawResult().rawBaseline() != null)
                    .max(Map.Entry.comparingByKey())
                    .orElse(null);
            boolean useInitializationPrevious = previousSeed != null && (previousPublished == null
                    || previousSeed.getKey().isAfter(previousPublished.getKey()));
            if (useInitializationPrevious) {
                InitialBaselineSeed previousSeedValue = previousSeed.getValue();
                int distance = Math.toIntExact(java.time.Duration.between(
                        previousSeed.getKey(), pointTime).toMinutes());
                result.add(new WindowValueTrace(pointTime, previousSeed.getKey(),
                        previousSeedValue.rawResult().rawBaseline(),
                        "当前初始化点缺失或无有效B0，采用最近有效初始化前值；该补值仅用于本次计算，不修改初始化记录和已发布结果",
                        "初始化前值", distance));
                continue;
            }
            if (previousPublished != null) {
                UserBaselineLoad previous = previousPublished.getValue();
                LocalDateTime previousTime = previousPublished.getKey();
                int distance = Math.toIntExact(java.time.Duration.between(previousTime, pointTime).toMinutes());
                result.add(new WindowValueTrace(pointTime, previousTime,
                        storageSupport.fromScaledLong(previous.getFinalBaselineE6()),
                        "历史最终基线和当前初始化点缺失，采用最近有效已发布前值", "前值", distance));
                continue;
            }
            if (seed != null && seed.rawResult() != null) {
                result.add(new WindowValueTrace(pointTime, seed.pointTime(), null,
                        "首次初始化已按历史业务日期" + seed.dataDate() + "第" + seed.slotNo()
                                + "点计算B0，但未取得有效结果；" + seed.rawResult().chineseRemark(),
                        "初始化失败", 0));
            }
            return new WindowBuild(result, pointTime);
        }
        return new WindowBuild(result, null);
    }
    private String chineseSource(String sourceType) {
        if (sourceType == null || sourceType.isBlank()) {
            return "负荷来源类型未标注";
        }
        return switch (sourceType.trim().toUpperCase()) {
            case "DEVICE" -> "设备负荷汇总";
            case "STATION" -> "场站负荷汇总";
            case "STAKE" -> "充电桩负荷汇总";
            case "MANUAL" -> "人工维护负荷";
            default -> "负荷来源代码“" + sourceType + "”";
        };
    }
WindowBuild actual(LocalDateTime t,Map<LocalDateTime,UserLoadPoint> s){return buildActualWindow(t,s);}
WindowBuild baseline(LocalDateTime t,Map<LocalDateTime,UserBaselineLoad> s,Map<LocalDateTime,InitialBaselineSeed> i){return buildBaselineWindow(t,s,i);}
record WindowBuild(List<WindowValueTrace> values, LocalDateTime missingTime) {}
}

public class FixtureCheck {
 static Map<String,Map<LocalDate,Map<Integer,UserLoadPoint>>> loads=new HashMap<>();
 static TypicalSampleSelector selector=new TypicalSampleSelector();static UserBaselinePointCalculator calc=new UserBaselinePointCalculator();static Windows win=new Windows();
 static RawBaselineResult raw(String a,LocalDate d,int slot){List<BaselineCalendarDay> h=new ArrayList<>();for(int i=1;i<=160;i++)h.add(new BaselineCalendarDay(d.minusDays(i)));return calc.calculateRaw(selector.select(new BaselineCalendarDay(d),h,Set.of(),loads.get(a),slot));}
 static RawBaselineResult rawTime(String a,LocalDateTime t){LocalDate d=t.toLocalTime().equals(LocalTime.MIDNIGHT)?t.toLocalDate().minusDays(1):t.toLocalDate();int slot=(int)java.time.Duration.between(d.atStartOfDay(),t).toMinutes()/15;return raw(a,d,slot);}
 static void eq(Object expected,Object got,String label){if(expected==null?got!=null:!expected.equals(got))throw new AssertionError(label+": expected "+expected+" got "+got);}
 static void num(String expected,BigDecimal got,String label){if(expected.isEmpty()){eq(null,got,label);}else if(got==null||new BigDecimal(expected).compareTo(got)!=0)throw new AssertionError(label+": expected "+expected+" got "+got);}
 public static void main(String[] args)throws Exception{
  for(String l:Files.readAllLines(Path.of(args[0]))){if(l.startsWith("cons_no"))continue;String[] p=l.split(",",-1);if(p[3].isEmpty())continue;loads.computeIfAbsent(p[0],k->new HashMap<>()).computeIfAbsent(LocalDate.parse(p[1]),k->new HashMap<>()).put(Integer.parseInt(p[2]),new UserLoadPoint(p[3],p[4]));}
  int passed=0;
  for(String l:Files.readAllLines(Path.of(args[1]))){String[] p=l.split("\t",-1);String id=p[0],a=p[1];LocalDate d=LocalDate.parse(p[2]);int slot=Integer.parseInt(p[3]);LocalDateTime t=d.atStartOfDay().plusMinutes(slot*15L);RawBaselineResult r=raw(a,d,slot);
   if(!p[4].isEmpty())eq(Integer.parseInt(p[4]),r.samples().size(),id+" samples");if(!p[5].isEmpty())eq(Long.parseLong(p[5]),r.samples().stream().filter(TypicalSampleTrace::fitted).count(),id+" fitted");eq(Integer.parseInt(p[6]),r.removedSamples().size(),id+" removed");num(p[7],r.rawBaseline(),id+" B0");eq(p[8],r.status(),id+" initial");
   String status=r.status();BigDecimal k=null,fin=r.rawBaseline();
   if(r.hasRemovedSample()){
    Map<LocalDateTime,UserLoadPoint> actual=new HashMap<>();for(var de:loads.get(a).entrySet())for(var pe:de.getValue().entrySet()){LocalDateTime pt=de.getKey().atStartOfDay().plusMinutes(pe.getKey()*15L);if(!pt.isBefore(t.minusHours(8))&&!pt.isAfter(t))actual.put(pt,pe.getValue());}
    Map<LocalDateTime,UserBaselineLoad> base=new HashMap<>();Map<LocalDateTime,InitialBaselineSeed> seeds=new HashMap<>();
    for(int i=32;i>=1;i--){LocalDateTime pt=t.minusMinutes(i*15L);RawBaselineResult br=rawTime(a,pt);base.put(pt,new UserBaselineLoad(br.rawBaseline(),br.status()));}
    if(id.equals("S09-ROLLING"))base.put(t.minusMinutes(15),new UserBaselineLoad(new BigDecimal("12"),"CORRECTED"));
    var aw=win.actual(t,actual);var bw=win.baseline(t,base,seeds);CorrectionResult cr=calc.calculateCorrection(r.rawCalculationValue(),r.rawBaseline(),aw.values(),bw.values());status=cr.status();k=cr.kValue();fin=cr.finalBaseline();
    if(status.equals("CORRECTED")){num(p[12],cr.actualMean(),id+" actualMean");num(p[13],cr.baselineMean(),id+" baselineMean");}
    if(id.equals("S13"))eq("前值",aw.values().stream().filter(x->x.targetTime().toLocalTime().equals(LocalTime.of(7,30))).findFirst().get().direction(),"S13 direction");
    if(id.equals("S14"))eq("后值",aw.values().getFirst().direction(),"S14 direction");
    if(id.equals("S01-MIDNIGHT")){
     for(int i=16;i>=1;i--){LocalDateTime pt=t.minusMinutes(i*15L);LocalDate bd=pt.toLocalTime().equals(LocalTime.MIDNIGHT)?pt.toLocalDate().minusDays(1):pt.toLocalDate();int sl=(int)java.time.Duration.between(bd.atStartOfDay(),pt).toMinutes()/15;seeds.put(pt,new InitialBaselineSeed(pt,bd,sl,rawTime(a,pt)));}
     var seeded=calc.calculateCorrection(r.rawCalculationValue(),r.rawBaseline(),aw.values(),win.baseline(t,Map.of(),seeds).values());num("1",seeded.kValue(),"midnight seed K");num("10",seeded.finalBaseline(),"midnight seed final");
    }
   }
   eq(p[9],status,id+" status");num(p[10],k,id+" K");num(p[11],fin,id+" final");System.out.println("PASS "+id+" samples="+r.samples().size()+" fitted="+r.samples().stream().filter(TypicalSampleTrace::fitted).count()+" removed="+r.removedSamples().size()+" B0="+r.rawBaseline()+" K="+k+" final="+fin+" "+status);passed++;
  }
  System.out.println("Algorithm cases passed: "+passed);
 }
}
