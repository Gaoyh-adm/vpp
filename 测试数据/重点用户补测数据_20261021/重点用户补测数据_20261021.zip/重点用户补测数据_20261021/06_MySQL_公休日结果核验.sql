-- First generate business date 2026-10-18; correction not required for this check.
SELECT cons_no,slot_no,day_type,JSON_LENGTH(sample_detail_json) AS sample_count,raw_baseline_mw,correction_status,sample_detail_json FROM ra_user_baseline_detail WHERE data_date='2026-10-18' AND calc_version='V1' AND deleted=0 AND cons_no='100023456827' AND slot_no=41;
-- Expected day_type RESTDAY, B0/final20, NOT_REQUIRED; sample dates must be RESTDAY in the real calendar. Count depends on calendar and availability.
SELECT calendar_date,day_type FROM ra_calendar_day WHERE calendar_date<'2026-10-18' AND day_type='RESTDAY' AND deleted=0 ORDER BY calendar_date DESC LIMIT 20;
