#!/usr/bin/env python3
"""Generate deterministic TDengine load fixtures. Does not connect to any database."""
from pathlib import Path
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from collections import Counter
import argparse, csv, hashlib, json, re, shutil, zipfile

D = Decimal
SPECS = [
('3750016959530','S01','正常选样；另测00:15跨日初始化','10',5,0,0,None,'10',None,None),
('3750016959531','S02','缺点先跳过，继续选更早真实值','10',5,0,0,None,'10',None,None),
('3750016959532','S03','仅1个真实样本，补4个同类型拟合样本','10',5,4,0,None,'10',None,None),
('3750016959533','S04','整日缺失仍可作为拟合目标日','10',5,1,0,None,'10',None,None),
('3750016959534','S05','只有最近1天可用，有几天算几天','10',1,0,0,None,'10',None,None),
('3750016959535','S06','历史同一点均缺失，仅该点无基线',None,0,0,0,None,None,None,None),
('3750016959536','S07','18恰好等于均值12的1.5倍，不剔除','12',5,0,0,None,'12',None,None),
('3750016959537','S08','剔除单个高值，K上调到1.2','10',5,0,1,'1.2','12','12','10'),
('3750016959538','S09','10:15和10:30连续修正，滚动使用最终值','10',5,0,1,'1.2','12','12','10'),
('3750016959539','S10','剔除后K下调到0.8','10',5,0,1,'0.8','8','8','10'),
('3750016959540','S11','实际负荷为0，K=0，结果为0','10',5,0,1,'0','0','0','10'),
('3750016959541','S12','历史基线窗口均值0，无法修正','10',5,0,1,None,'10','12','0'),
('3750016959542','S13','实际07:30缺点，同距离优先前值','10',5,0,1,'1.175','11.75','11.75','10'),
('3750016959543','S14','实际06:15无可用前值，采用06:30后值','10',5,0,1,'1.225','12.25','12.25','10'),
('3750016959544','S15','实际窗口及可拟合范围无值，无法修正','10',5,0,1,None,'10',None,'10'),
('3750016959545','S16','历史基线07:30空，用最近已发布前值','10',5,0,1,'1.2','12','12','10'),
('3750016959546','S17','[100,100,10,10,10]一次剔除两个高值','10',5,0,2,'1.2','12','12','10'),
('3750016959547','S18','[100,40,10,10,10]只剔除100，不迭代','17.5',5,0,1,'1.2','21','12','10'),
('3750016959548','S19','只有[40,10]两个样本，仍按实际数量剔除','10',2,0,1,'1.2','12','12','10'),
('3750016959549','S20','零负荷是有效样本；来源类型为空','0',5,0,0,None,'0',None,None),
]


def sqlstr(value):
    if value is None:
        return 'NULL'
    return "'" + str(value).replace("'", "''") + "'"


def fmt(value):
    return 'NULL' if value is None else format(value, '.4f').rstrip('0').rstrip('.') if value else '0'


def workdays_before(target, n=5):
    out=[]; current=target-timedelta(days=1)
    while len(out)<n:
        if current.weekday()<5: out.append(current)
        current-=timedelta(days=1)
    return out


def special_load(account, business_date, slot, target, previous):
    code = ACCOUNT_CASE[account]
    base = D('10') if business_date.weekday()<5 else D('20')
    historical = business_date < target
    if code == 20:
        return D('0')
    if historical:
        if code == 1 and business_date == previous[0] and slot == 1:
            return D('30')
        if code in (3,4) and business_date == previous[0]:
            return None
        if code == 16 and slot == 30:
            return None
        if code == 12 and slot != 41:
            return D('0')
        if slot == 41:
            if code == 2 and business_date == previous[0]: return None
            if code == 3: return D('10') if business_date == previous[-1] else None
            if code == 4: return D('10') if business_date in previous[1:] else None
            if code == 5: return D('10') if business_date == previous[0] else None
            if code == 6: return None
            if code == 7 and business_date in previous:
                return D('18') if business_date == previous[0] else D('10.5')
            if code == 17 and business_date in previous[:2]: return D('100')
            if code == 18:
                if business_date == previous[0]: return D('100')
                if business_date == previous[1]: return D('40')
            if code == 19:
                return D('40') if business_date == previous[0] else D('10') if business_date == previous[1] else None
            if code in (8,9,10,11,12,13,14,15,16) and business_date == previous[0]:
                return D('30')
            if code == 12: return D('10')
        if code == 9 and slot == 42 and business_date == previous[0]:
            return D('30')
        return base
    if code in (8,9,12,13,14,15,16,17,18,19): base=D('12')
    if code == 10: base=D('8')
    if code == 11: base=D('0')
    if code == 13:
        if slot == 29: return D('8')
        if slot == 30: return None
        if slot == 31: return D('16')
    if code == 14:
        if slot <= 25: return None
        if slot == 26: return D('14')
    if code == 15 and slot <= 41: return None
    return base


# Keep all nine original scenario accounts present in the supplied active-user list.
# Reassign the other eleven scenarios to accounts in that same list.
CASE_ACCOUNTS = {
    'S01': '100023456827', 'S02': '100023456831', 'S03': '100023456832',
    'S04': '3750016959533', 'S05': '3750016959534', 'S06': '100555666',
    'S07': '3750016959536', 'S08': '1555553333', 'S09': '3750016959538',
    'S10': '1020261013', 'S11': '3750016959540', 'S12': '3750013059405',
    'S13': '3700990960038', 'S14': '3750016959543', 'S15': '3750016959544',
    'S16': '3750007283057', 'S17': '3750016959546', 'S18': '3750004371089',
    'S19': '3750007840519', 'S20': '3750016959549',
}
SPECS = [(CASE_ACCOUNTS[item[1]], *item[1:]) for item in SPECS]
ACCOUNT_CASE = {account: int(case[1:]) for account, case, *_ in SPECS}

def child_table(account, business_date):
    return 'fixture_load_' + hashlib.sha256(account.encode()).hexdigest()[:24] + '_' + business_date.strftime('%Y%m%d')


def write_csv(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as out:
        w = csv.DictWriter(out, fieldnames=list(rows[0]), lineterminator='\n')
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description='Generate one TDengine SQL file for 20 scenario accounts from the supplied list. No database connection.')
    ap.add_argument('--accounts', type=Path, default=Path(__file__).with_name('有效户号.txt'))
    ap.add_argument('--out', type=Path, default=Path(__file__).parent)
    ap.add_argument('--target-date', default='2026-10-21')
    ap.add_argument('--days', type=int, default=30)
    ap.add_argument('--database', default='vpp_resource')
    args = ap.parse_args()
    target = date.fromisoformat(args.target_date)
    assert target.weekday() < 5, 'These main test scenarios require an ordinary workday; also check the real MySQL calendar.'
    assert args.days >= 10
    assert re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', args.database)
    active = args.accounts.read_text(encoding='utf-8-sig').split()
    assert len(active) == len(set(active))
    accounts = [s[0] for s in SPECS]
    assert len(accounts) == len(set(accounts)) == 20
    assert set(accounts) <= set(active), 'All scenario accounts must come from the supplied user list.'
    assert all(re.fullmatch(r'[A-Za-z0-9_-]{1,40}', a) for a in accounts)
    out = args.out
    (out/'validation').mkdir(parents=True, exist_ok=True)
    if args.accounts.resolve() != (out/'有效户号.txt').resolve():
        shutil.copyfile(args.accounts, out/'有效户号.txt')
    start = target-timedelta(days=args.days-1)
    previous = workdays_before(target)
    table_count = 0; rows = 0; nulls = 0; by_day = []
    with (out/'01_TDengine_重点用户负荷补测.sql').open('w', encoding='utf-8', newline='\n') as f, (out/'validation/case_loads.csv').open('w', encoding='utf-8', newline='') as v:
        f.write('-- Only the 20 scenario accounts, using the existing two-tag supertable. One statement per line.\n')
        f.write(f'USE {args.database};\n')
        w = csv.writer(v, lineterminator='\n'); w.writerow(['cons_no','data_date','slot_no','load_mw','src_type'])
        for offset in range(args.days):
            day = start+timedelta(days=offset); dstr = str(day); day_nulls = 0
            for account in accounts:
                table = child_table(account, day); table_count += 1
                f.write(f'CREATE TABLE IF NOT EXISTS {table} USING st_user_load_96 TAGS ({sqlstr(account)}, {sqlstr(dstr)});\n')
                values=[]; src = None if ACCOUNT_CASE[account] == 20 else 'MANUAL'
                for slot in range(1,97):
                    ts = datetime.combine(day,time())+timedelta(minutes=slot*15)
                    value = special_load(account, day, slot, target, previous)
                    day_nulls += value is None
                    values.append(f'({sqlstr(ts.strftime("%Y-%m-%d %H:%M:%S.000"))},{fmt(value)},{sqlstr(src)})')
                    w.writerow([account,dstr,slot,'' if value is None else str(value),'' if src is None else src])
                f.write(f'INSERT INTO {table} (ts,load_mw,src_type) VALUES '+ ' '.join(values)+';\n')
                rows += 96
            nulls += day_nulls
            by_day.append(dict(data_date=dstr,rows=1920,null_load_rows=day_nulls))
    expected=[]
    for account,case,scenario,b0,n,fitted,removed,k,final,actual_mean,baseline_mean in SPECS:
        initial='NO_BASELINE' if b0 is None else 'WAITING' if removed else 'NOT_REQUIRED'
        final_status=initial if not removed else 'UNCORRECTABLE' if k is None else 'CORRECTED'
        expected.append(dict(case=case,cons_no=account,business_date=str(target),slot_no=41,target_time=str(target)+' 10:15:00',scenario=scenario,sample_count=n,fitted_count=fitted,removed_count=removed,b0=b0,initial_status=initial,final_status=final_status,k=k,final_baseline=final,actual_mean=actual_mean,baseline_mean=baseline_mean))
    expected.append(dict(expected[0],case='S01-MIDNIGHT',slot_no=1,target_time=str(target)+' 00:15:00',scenario='跨日窗口及首次初始化',removed_count=1,initial_status='WAITING',final_status='CORRECTED',k='1',final_baseline='10',actual_mean='10',baseline_mean='10'))
    expected.append(dict(expected[8],case='S09-ROLLING',slot_no=42,target_time=str(target)+' 10:30:00',scenario='使用10:15修正后12，基线窗口均值10.125',k='1.185185',final_baseline='11.851851',baseline_mean='10.125'))
    expected.append(dict(expected[15],case='S16-MISSING-POINT',slot_no=30,target_time=str(target)+' 07:30:00',scenario='窗口补值不改变原07:30无基线输出',sample_count=0,fitted_count=0,removed_count=0,b0=None,initial_status='NO_BASELINE',final_status='NO_BASELINE',k=None,final_baseline=None,actual_mean=None,baseline_mean=None))
    rest_target=target-timedelta(days=1)
    while rest_target.weekday()!=6: rest_target-=timedelta(days=1)
    expected.append(dict(expected[0],case='S01-REST',business_date=str(rest_target),target_time=str(rest_target)+' 10:15:00',scenario='公休日选样，具体样本日期与数量以实际日历为准',sample_count=None,fitted_count=None,b0='20',final_baseline='20'))
    write_csv(out/'预期结果.csv',expected)
    (out/'expected_cases.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2),encoding='utf-8')
    mapping=[dict(case=s[1],cons_no=s[0],scenario=s[2]) for s in SPECS]
    write_csv(out/'重点用户场景分配.csv',mapping)
    keys=['case','cons_no','business_date','slot_no','sample_count','fitted_count','removed_count','b0','initial_status','final_status','k','final_baseline','actual_mean','baseline_mean']
    (out/'validation/expected.tsv').write_text('\n'.join('\t'.join('' if row[key] is None else str(row[key]) for key in keys) for row in expected)+'\n',encoding='utf-8')
    stats=dict(database=args.database,target_date=str(target),start_date=str(start),end_date=str(target),provided_accounts=len(active),scenario_accounts=20,child_tables_reused=table_count,physical_rows=rows,nonnull_load_rows=rows-nulls,null_load_rows=nulls,previous_five_weekdays=list(map(str,previous)),days_detail=by_day)
    (out/'生成统计.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    quoted=','.join(sqlstr(a) for a in accounts);a=CASE_ACCOUNTS
    sc03=child_table(a['S03'],previous[0]);sc06=child_table(a['S06'],previous[0]);sc13=child_table(a['S13'],target)
    checks=f'''-- All statements are scoped to the 20 selected accounts or an exact child table.
SELECT COUNT(*), COUNT(load_mw) FROM {args.database}.{sc03};
-- Expected 96, 0: this also verifies explicit NULL replaced the old synthetic values.
SELECT ts,load_mw,cons_no,data_date FROM {args.database}.{sc06} WHERE ts='{previous[0]} 10:15:00';
-- Expected one row with load_mw NULL.
SELECT COUNT(*), COUNT(load_mw) FROM {args.database}.st_user_load_96 WHERE cons_no IN ({quoted}) AND ts>'{start} 00:00:00' AND ts<='{target+timedelta(days=1)} 00:00:00';
-- Expected {rows}, {rows-nulls}; NULL loads={nulls}.
SELECT COUNT(*), COUNT(load_mw) FROM {args.database}.st_user_load_96 WHERE cons_no IN ({quoted}) AND data_date='{target}' AND ts>'{target} 00:00:00' AND ts<='{target+timedelta(days=1)} 00:00:00';
-- Expected 1920, {1920-by_day[-1]['null_load_rows']}.
SELECT ts,load_mw FROM {args.database}.{sc13} WHERE ts>='{target} 07:15:00' AND ts<='{target} 07:45:00' ORDER BY ts;
-- Expected 8, NULL, 16.
'''
    (out/'02_TDengine_导入核验.sql').write_text(checks,encoding='utf-8')
    scope=f"data_date='{target}' AND calc_version='V1' AND deleted=0 AND cons_no IN ({quoted})"
    selected=f"(slot_no=41 OR (cons_no='{a['S01']}' AND slot_no=1) OR (cons_no='{a['S09']}' AND slot_no=42) OR (cons_no='{a['S16']}' AND slot_no=30))"
    sql=f'''-- Run on MySQL after full regeneration; run again after correction jobs.
SELECT correction_status,sync_status,COUNT(*) AS point_count FROM ra_user_baseline_detail WHERE {scope} GROUP BY correction_status,sync_status;
-- Before correction: NOT_REQUIRED=1904, NO_BASELINE=2, WAITING=14. After: NOT_REQUIRED=1904, NO_BASELINE=2, CORRECTED=12, UNCORRECTABLE=2. All 1920 points should be SYNCED.
SELECT cons_no,slot_no,generated_at,correction_status,JSON_LENGTH(sample_detail_json) AS sample_count,removed_count,raw_baseline_mw,k_value,final_baseline_mw,sync_status FROM ra_user_baseline_detail WHERE {scope} AND {selected} ORDER BY cons_no,slot_no;
SELECT cons_no,slot_no,JSON_EXTRACT(sample_detail_json,'$[*].targetDate') AS sample_dates,JSON_EXTRACT(sample_detail_json,'$[*].sourceDate') AS source_dates,JSON_EXTRACT(sample_detail_json,'$[*].fitted') AS fitted_flags,initial_mean_mw,threshold_mw,removed_sample_json FROM ra_user_baseline_detail WHERE {scope} AND slot_no=41 ORDER BY cons_no;
SELECT cons_no,slot_no,correction_status,raw_baseline_mw,final_baseline_mw FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S06']}' AND slot_no IN (40,41,42) ORDER BY slot_no;
-- S06: slots 40 and 42 have baseline10; only slot41 is NO_BASELINE.
'''
    (out/'03_MySQL_基线结果核验.sql').write_text(sql,encoding='utf-8')
    window=f'''-- MySQL; check actual sourceTime/value/direction/distanceMinutes, not just the final number.
SELECT cons_no,slot_no,JSON_EXTRACT(actual_window_json,'$[5]') AS fitted_point FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S13']}' AND slot_no=41;
-- 07:30 target takes 07:15 actual8, direction=前值, distance15; K1.175, final11.75.
SELECT cons_no,slot_no,JSON_EXTRACT(actual_window_json,'$[0]') AS fitted_point FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S14']}' AND slot_no=41;
-- 06:15 target takes 06:30 actual14, direction=后值, distance15; K1.225, final12.25.
SELECT cons_no,slot_no,JSON_EXTRACT(baseline_window_json,'$[5]') AS fitted_point FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S16']}' AND slot_no=41;
-- 07:30 baseline target takes 07:15 final10; original07:30 output remains NO_BASELINE.
SELECT cons_no,slot_no,JSON_EXTRACT(baseline_window_json,'$[15]') AS rolling_point FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S09']}' AND slot_no=42;
-- 10:30 window includes 10:15 corrected12; baseline mean10.125.
SELECT cons_no,slot_no,JSON_EXTRACT(baseline_window_json,'$[0]') AS first_point,JSON_EXTRACT(baseline_window_json,'$[15]') AS last_point,calculation_remark FROM ra_user_baseline_detail WHERE {scope} AND cons_no='{a['S01']}' AND slot_no=1;
-- Window points: previous day20:15 through current day00:00. For initialization, both belong to the previous business date, last slot96.
SELECT cons_no,first_target_time,JSON_LENGTH(seed_window_json) AS seed_count,JSON_EXTRACT(seed_window_json,'$[0]') AS first_seed,JSON_EXTRACT(seed_window_json,'$[15]') AS last_seed FROM ra_user_baseline_initial_window WHERE cons_no='{a['S01']}' AND calc_version='V1' AND deleted=0;
-- If no previous final baselines existed: 16 seeds, correct previous-day business dates; K1 and final10.
SELECT cons_no,slot_no,correction_status,k_value,final_baseline_mw,calculation_remark FROM ra_user_baseline_detail WHERE {scope} AND cons_no IN ('{a['S12']}','{a['S15']}') AND slot_no=41;
-- Two distinct reasons: baseline window mean0; actual window cannot be completed. Both keep B0=10 and NULL K.
'''
    (out/'04_MySQL_拟合和窗口来源核验.sql').write_text(window,encoding='utf-8')
    td=f'''SELECT cons_no,slot_no,correction_status,raw_baseline_e6/1000000.0 AS b0,k_e6/1000000.0 AS k_value,final_baseline_e6/1000000.0 AS final_mw FROM {args.database}.st_user_baseline_load WHERE cons_no IN ({quoted}) AND data_date='{target}' AND calc_version='V1' AND ts>'{target} 00:00:00' AND ts<='{target+timedelta(days=1)} 00:00:00' AND {selected} ORDER BY cons_no,ts;
-- Expected the same 23 primary-day points as the selected MySQL query.
'''
    (out/'05_TDengine_最终结果核验.sql').write_text(td,encoding='utf-8')
    rest=f'''-- First generate business date {rest_target}; correction not required for this check.
SELECT cons_no,slot_no,day_type,JSON_LENGTH(sample_detail_json) AS sample_count,raw_baseline_mw,correction_status,sample_detail_json FROM ra_user_baseline_detail WHERE data_date='{rest_target}' AND calc_version='V1' AND deleted=0 AND cons_no='{a['S01']}' AND slot_no=41;
-- Expected day_type RESTDAY, B0/final20, NOT_REQUIRED; sample dates must be RESTDAY in the real calendar. Count depends on calendar and availability.
SELECT calendar_date,day_type FROM ra_calendar_day WHERE calendar_date<'{rest_target}' AND day_type='RESTDAY' AND deleted=0 ORDER BY calendar_date DESC LIMIT 20;
'''
    (out/'06_MySQL_公休日结果核验.sql').write_text(rest,encoding='utf-8')
    preflight=f'''-- Optional read-only checks. Do not alter actual calendar or unit participation marks for these fixtures.
SELECT calendar_date,day_type FROM ra_calendar_day WHERE calendar_date<'{target}' AND day_type='WORKDAY' AND deleted=0 ORDER BY calendar_date DESC LIMIT 30;
SELECT u.cons_no,u.unit_id,a.adjust_date,a.participate FROM ra_aggregate_user u JOIN ra_adjustment_day a ON a.unit_id=u.unit_id WHERE u.cons_no IN ({quoted}) AND a.adjust_date>='{start}' AND a.adjust_date<'{target}' AND a.participate=1 AND a.deleted=0 ORDER BY u.cons_no,a.adjust_date;
'''
    (out/'07_MySQL_日历和参与记录检查.sql').write_text(preflight,encoding='utf-8')
    lines=['| 场景 | 户号 | 验证内容 |','|---|---|---|']+[f'| {r["case"]} | {r["cons_no"]} | {r["scenario"]} |' for r in mapping]
    readme=f'''# 重点用户补测数据

目标业务日：{target}；模拟负荷日期：{start}—{target}。
从你新提供的{len(active)}个户号中选择20户，保留原来已在名单中的9个重点户号，其他11个场景重新分配到名单内户号。名单不做启停、删除状态变更。
本包仅更新20户×{args.days}天×96点={rows:,}条模拟负荷，含{nulls}个NULL负荷；不需要重导全部893户。

## 服务器执行

上传并解压本包后，进入解压后的目录，直接执行一个文件：

```sh
taos -u root -p -f "$PWD/01_TDengine_重点用户负荷补测.sql"
```

- 固定使用现有`{args.database}.st_user_load_96`。普通列为ts TIMESTAMP、load_mw DOUBLE、src_type NCHAR(20)；TAG依次为cons_no NCHAR(40)、data_date NCHAR(10)。
- 表名与原包相同，按“户号哈希＋业务日期”定位。原包已完整导入时复用{table_count}张已有子表，不另建同一户号同一天的第二份数据。不存在的子表才CREATE IF NOT EXISTS。
- 所有DDL、INSERT均一条完整SQL一行；每个INSERT含96组值。无CREATE DATABASE、DROP、DELETE，只有选定20户的模拟负荷会被写入覆盖。
- NULL是显式缺点；首先执行`02_TDengine_导入核验.sql`前两条，核对S03整日非空数0、S06指定点NULL，确认原模拟非空值已被替换成缺点。若不符合，先停在导入核验阶段，不按旧数据评价算法。
- 00:15为slot1，次日00:00为slot96；后者仍属于前一业务日期TAG。

## 运行基线和修正

1. 先执行`02_TDengine_导入核验.sql`。重点20户整月应为{rows:,}条、非空{rows-nulls:,}条，当天1920条、非空{1920-by_day[-1]['null_load_rows']}条。
2. XXL-JOB执行`generateDailyUserBaseline`，参数`{target}`。必须是当前已经支持的同日全量重算，覆盖旧明细及修正结果；可检查generated_at确实刷新。该任务仍处理应用全部有效用户，本包结果统计SQL只筛选这20户。
3. 执行`correctDueUserBaseline`。请沿用已修复的应用MySQL会话时区+08:00，确认数据库NOW与北京时间一致。
4. 执行`03_MySQL_基线结果核验.sql`及`04_MySQL_拟合和窗口来源核验.sql`。不能只看最终数值，还要看sample_detail_json的来源日期、fitted标记和窗口JSON中的sourceTime、direction、distanceMinutes。
5. 执行`05_TDengine_最终结果核验.sql`，与MySQL逐点对照。
6. 公休日单独执行生成任务，参数`{rest_target}`；然后执行`06_MySQL_公休日结果核验.sql`。S01的10:15应为20MW，不需要修正。

在以下日历与参与前提满足时，主验证日重点20户的预期状态合计：

| 阶段 | NOT_REQUIRED | NO_BASELINE | WAITING | CORRECTED | UNCORRECTABLE | 合计 |
|---|---:|---:|---:|---:|---:|---:|
| B0生成后、修正前 | 1904 | 2 | 14 | 0 | 0 | 1920 |
| 到期修正完成后 | 1904 | 2 | 0 | 12 | 2 | 1920 |

修正任务对应3个时刻：00:15共1个用户点、10:15共12个用户点、10:30共1个用户点。生成后若修正任务已自动执行，可能直接看到第二行状态。

## 场景分配

{chr(10).join(lines)}

`预期结果.csv`包含24个检查点：20个主场景＋跨日点＋连续修正第二点＋S16缺失基线辅助点＋公休日点。

## 重点核对

- S02：先跳过20日缺点，选19、16、15、14、13日真实值，5个样本全部fitted=false。
- S03：仅14日10:15有真实值，其余4个样本拟合自14日；S04：20日整日缺失，仍可作为拟合目标日，10:15从19日补。
- S05：仅1个样本照算B0=10；S06：10:15为NO_BASELINE，相邻10:00、10:30仍有B0=10。
- S07：最高值18恰好等于阈值18，不剔除，B0=12、K为空。
- S10：K=0.8、最终8；S12：基线窗口均值0，无法修正，保留10。
- S13：实际07:30取前方07:15的8，不取后方16，K=1.175、最终11.75。
- S14：实际06:15取后方06:30的14，K=1.225、最终12.25。
- S16：07:30基线缺失，计算K时取已发布07:15的10；07:30原输出仍为NO_BASELINE，10:15最终12。
- S18：[100,40,10,10,10]只剔除100，B0=17.5、最终21；S19：只有[40,10]两天仍剔除40，B0=10、最终12。
- S01额外验证00:15，窗口跨到前一天。没有前一天最终基线时才验证到首次初始化；已有历史结果时核验的是历史最终基线路径，不删除历史结果来伪造首次启动。若前一天已发布的窗口值不是10，K须按真实历史最终窗口计算，不能硬套K=1的初始化期望。
- S12/S15无法修正时，当前代码把两个窗口均值字段保存为空；CSV均值只是解释数学条件。

## 前提与覆盖范围

- 主验证日前5个WORKDAY预期为{', '.join(map(str,previous))}，20个重点户号的聚合单元参与标记不能把这些日期替换掉。日历或参与记录不同，请先通过07号只读SQL核对实际选样，不修改真实日历或参与标记来强凑期望。
- 参与标记属于聚合单元，本包不擅自新增或修改；参与日补足分支需另行准备聚合单元级参与记录后验证。
- 节假日暂不设计专门用例。仅{args.days}个自然日的数据不能完整验证30个工作日/20个公休日的搜索边界，需要更早的边界样本。
- 包中的生成器只生成SQL，不连接数据库，不自动执行SQL；只依赖Python标准库，不依赖云端仓库路径。Windows可在本目录执行：

```powershell
py -3 -X utf8 .\\generate_fixture.py --out .\\generated
```

## 验证材料

`validation/case_loads.csv`是20户完整输入；`expected_cases.json`、`预期结果.csv`是期望结果。隔离计算验证记录另见`验证报告.txt`；这不代表已经在你的数据库执行。
'''
    (out/'README.md').write_text(readme,encoding='utf-8')
    print(json.dumps(dict(out=str(out),selected_accounts=20,rows=rows,nulls=nulls,checks=len(expected)),ensure_ascii=False))


if __name__=='__main__':
    main()
